package ir.arsacia.hub

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private val pages = linkedMapOf<String, String>()
    private val webViews = linkedMapOf<String, WebView>()
    private var currentKey: String? = null
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val filePickerRequest = 4107
    private val red = Color.rgb(255, 38, 59)
    private val dark = Color.rgb(9, 9, 13)

    private val labels = linkedMapOf(
        "forum" to "فروم آرساکیا",
        "sa" to "پنل کاربری آرساکیا",
        "wiki" to "ویکی آرساکیا",
        "uploadkon" to "Uploadkon",
        "imgurl" to "Imgurl",
        "uupload" to "My UUpload",
        "picofile" to "Picofile",
        "10script" to "Up.10script",
        "toolschi" to "Toolschi"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pages.putAll(linkedMapOf(
            "forum" to "https://forum.arsacia.ir",
            "sa" to "https://sa.arsacia.ir",
            "wiki" to "https://wiki.arsacia.ir",
            "uploadkon" to "https://uploadkon.ir",
            "imgurl" to "https://imgurl.ir",
            "uupload" to "https://my.uupload.ir",
            "picofile" to "https://picofile.com",
            "10script" to "https://up.10script.ir",
            "toolschi" to "https://toolschi.ir"
        ))
        buildHome()
    }

    private fun buildHome() {
        root = FrameLayout(this).apply { setBackgroundColor(dark) }
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        content.addView(makeHomeView(), FrameLayout.LayoutParams(-1, -1))

        val quick = Button(this).apply {
            text = "☰"
            textSize = 22f
            setTextColor(Color.WHITE)
            background = rounded(red, 100)
            elevation = 12f
            setOnClickListener { showSiteMenu() }
        }
        val lp = FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, dp(18), dp(22))
        root.addView(quick, lp)
        setContentView(root)
    }

    private fun makeHomeView(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(26), dp(22), dp(26))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(36, 17, 24), Color.rgb(13, 13, 18), dark)
            )
        }
        val title = TextView(this).apply {
            text = "ARSACIA HUB"
            textSize = 13f
            letterSpacing = .22f
            setTextColor(red)
            gravity = Gravity.CENTER
        }
        val heading = TextView(this).apply {
            text = "مرکز آرساکیا"
            textSize = 29f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(5))
        }
        val subtitle = TextView(this).apply {
            text = "همه سایت‌ها، یک‌جا داخل برنامه"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(28))
        }
        outer.addView(title)
        outer.addView(heading)
        outer.addView(subtitle)

        val main = listOf("forum", "sa", "wiki")
        main.forEach { key -> outer.addView(homeButton(labels.getValue(key)) { openSite(key) }) }
        outer.addView(homeButton("مرکز آپلود  •  ۶ ابزار") { showUploadMenu() })
        val hint = TextView(this).apply {
            text = "برای جابه‌جایی بین سایت‌ها، دکمه قرمز شناور را بزن."
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        outer.addView(hint)
        return outer
    }

    private fun homeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(37, 18, 25), 18).also {
                it.setStroke(dp(1), red)
            }
            elevation = dp(3).toFloat()
            setPadding(dp(12), dp(8), dp(12), dp(8))
            val p = LinearLayout.LayoutParams(-1, dp(58))
            p.setMargins(0, dp(6), 0, dp(6))
            layoutParams = p
            setOnClickListener { action() }
        }

    private fun openSite(key: String) {
        val existing = webViews[key]
        if (existing != null) {
            content.removeAllViews()
            content.addView(existing, FrameLayout.LayoutParams(-1, -1))
            currentKey = key
            return
        }
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // اگر پنجره انتخاب فایل قبلی باز مانده، آن را آزاد می‌کنیم.
                uploadCallback?.onReceiveValue(null)
                uploadCallback = filePathCallback

                val intent = try {
                    fileChooserParams?.createIntent()
                        ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                } catch (_: Exception) {
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                }

                return try {
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (_: Exception) {
                    uploadCallback?.onReceiveValue(null)
                    uploadCallback = null
                    false
                }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return false // لینک‌ها در همین WebView باز می‌شوند.
            }
        }
        web.setBackgroundColor(Color.WHITE)
        webViews[key] = web
        content.removeAllViews()
        content.addView(web, FrameLayout.LayoutParams(-1, -1))
        currentKey = key
        web.loadUrl(pages.getValue(key))
    }

    private fun showSiteMenu() {
        val keys = labels.keys.toList()
        val names = keys.map { labels.getValue(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("رفتن به بخش دیگر")
            .setItems(names) { _, which -> openSite(keys[which]) }
            .setNegativeButton("خانه") { _, _ -> goHome() }
            .setNeutralButton("بستن", null)
            .show()
    }

    private fun showUploadMenu() {
        val keys = listOf("uploadkon", "imgurl", "uupload", "picofile", "10script", "toolschi")
        val names = keys.map { labels.getValue(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("مرکز آپلود")
            .setItems(names) { _, which -> openSite(keys[which]) }
            .setNegativeButton("بازگشت", null)
            .show()
    }

    private fun goHome() {
        content.removeAllViews()
        content.addView(makeHomeView(), FrameLayout.LayoutParams(-1, -1))
        currentKey = null
    }


    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val result: Array<Uri>? = if (resultCode == Activity.RESULT_OK) {
                val clipData = data?.clipData
                when {
                    clipData != null -> Array(clipData.itemCount) { index ->
                        clipData.getItemAt(index).uri
                    }
                    data?.data != null -> arrayOf(data.data!!)
                    else -> null
                }
            } else null

            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        val key = currentKey
        if (key != null) {
            val web = webViews[key]
            if (web != null && web.canGoBack()) {
                web.goBack()
                return
            }
            goHome()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        uploadCallback?.onReceiveValue(null)
        uploadCallback = null
        webViews.values.forEach { it.destroy() }
        webViews.clear()
        super.onDestroy()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
